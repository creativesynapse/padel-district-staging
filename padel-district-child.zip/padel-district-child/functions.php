<?php
/**
 * Padel District child theme.
 *
 * How it works: when a visitor opens a page whose slug matches one of the keys
 * below (for example /courts/), this theme renders the full Padel District page
 * (header, content, footer, mobile booking bar, WhatsApp button) from the files in
 * /pd-pages and /pd-parts. The page can stay empty in the editor.
 *
 * You can also pick a "Padel District: …" template in the page's Template setting
 * to use any slug you like.
 *
 * @package padel-district
 */

defined( 'ABSPATH' ) || exit;

/* -------------------------------------------------------------------------
 * SETTINGS — edit here
 * ---------------------------------------------------------------------- */

/** WhatsApp number: country code + number, digits only, e.g. '60123456789'. Empty = "coming soon" panel. */
if ( ! defined( 'PD_WHATSAPP_NUMBER' ) ) {
	define( 'PD_WHATSAPP_NUMBER', '' );
}

define( 'PD_VERSION', '1.1.0' );

/**
 * Page map. Key => accepted slugs (first one is used when creating pages),
 * the page title used when creating it, and the SEO title + description.
 */
function pd_pages() {
	return array(
		'home'        => array(
			'slugs' => array( 'home' ),
			'title' => 'Home',
			'seo'   => 'Padel District | Padel Courts in Petaling Jaya',
			'desc'  => 'Discover Padel District in Kayu Ara, Petaling Jaya. Seven padel courts, a welcoming atmosphere and easy booking through Playtomic. Find your court.',
		),
		'courts'      => array(
			'slugs' => array( 'courts' ),
			'title' => 'Courts',
			'seo'   => 'Courts | Padel District',
			'desc'  => 'Seven indoor, panoramic doubles padel courts in Kayu Ara, Petaling Jaya: Centre Court and Padel 01–06. Book on Playtomic.',
		),
		'about'       => array(
			'slugs' => array( 'about', 'about-us' ),
			'title' => 'About',
			'seo'   => 'About | Padel District',
			'desc'  => 'Padel District is a padel venue in Kayu Ara, Petaling Jaya: seven indoor courts, open 7AM to midnight daily.',
		),
		'food-drinks' => array(
			'slugs' => array( 'food-drinks', 'food-and-drinks' ),
			'title' => 'Food & Drinks',
			'seo'   => 'Food &amp; Drinks | Padel District',
			'desc'  => 'Food and drinks are coming soon to Padel District, Petaling Jaya.',
		),
		'visit'       => array(
			'slugs' => array( 'visit', 'visit-us' ),
			'title' => 'Visit Us',
			'seo'   => 'Visit Us | Padel District',
			'desc'  => 'Directions, hours and parking for Padel District, 227 Jalan Kenanga, Kampung Sungai Kayu Ara, Petaling Jaya.',
		),
		'faq'         => array(
			'slugs' => array( 'faq', 'faqs' ),
			'title' => 'FAQ',
			'seo'   => 'FAQ | Padel District',
			'desc'  => 'Booking, rackets, parking and more: answers before your first game at Padel District.',
		),
		'privacy'     => array(
			'slugs' => array( 'privacy-policy', 'privacy' ),
			'title' => 'Privacy Policy',
			'seo'   => 'Privacy Policy | Padel District',
			'desc'  => 'Privacy Policy for Padel District.',
		),
		'terms'       => array(
			'slugs' => array( 'terms', 'website-terms', 'terms-and-conditions' ),
			'title' => 'Website Terms',
			'seo'   => 'Website Terms | Padel District',
			'desc'  => 'Website Terms for Padel District.',
		),
	);
}

/* -------------------------------------------------------------------------
 * HELPERS used by the template files
 * ---------------------------------------------------------------------- */

/** Published page for a key, or null. */
function pd_get_page( $key ) {
	static $cache = array();
	if ( array_key_exists( $key, $cache ) ) {
		return $cache[ $key ];
	}
	$pages = pd_pages();
	$found = null;
	if ( isset( $pages[ $key ] ) ) {
		// 1. A page that uses the matching "Padel District: …" template.
		$by_tpl = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'     => 'pd-' . $key,      // phpcs:ignore WordPress.DB.SlowDBQuery
				'no_found_rows'  => true,
			)
		);
		if ( $by_tpl ) {
			$found = $by_tpl[0];
		} else {
			// 2. A page with one of the accepted slugs.
			foreach ( $pages[ $key ]['slugs'] as $slug ) {
				$p = get_page_by_path( $slug, OBJECT, 'page' );
				if ( $p && 'publish' === $p->post_status ) {
					$found = $p;
					break;
				}
			}
		}
	}
	$cache[ $key ] = $found;
	return $found;
}

/** URL of a Padel District page. Home is the site root when it is the static homepage. */
function pd_url( $key ) {
	$page = pd_get_page( $key );
	if ( 'home' === $key ) {
		if ( ! $page || (int) get_option( 'page_on_front' ) === (int) $page->ID ) {
			return home_url( '/' );
		}
		return get_permalink( $page );
	}
	if ( $page ) {
		return get_permalink( $page );
	}
	$pages = pd_pages();
	return home_url( '/' . $pages[ $key ]['slugs'][0] . '/' );
}

/** Theme image URL. */
function pd_img( $file ) {
	return get_stylesheet_directory_uri() . '/assets/img/' . $file;
}

/** Prints aria-current="page" on the nav link for the current page. */
function pd_current( $key ) {
	if ( pd_current_key() === $key ) {
		echo ' aria-current="page"';
	}
}

/** Which Padel District page is being viewed, or '' when none. */
function pd_current_key() {
	static $key = null;
	if ( null !== $key ) {
		return $key;
	}
	$key = '';
	if ( ! is_page() ) {
		return $key;
	}
	$post = get_queried_object();
	if ( ! $post instanceof WP_Post ) {
		return $key;
	}
	$pages = pd_pages();

	// Template chosen in the editor wins.
	$tpl = get_page_template_slug( $post );
	if ( $tpl && 0 === strpos( $tpl, 'pd-' ) && isset( $pages[ substr( $tpl, 3 ) ] ) ) {
		$key = substr( $tpl, 3 );
		return $key;
	}
	// Otherwise match the slug.
	foreach ( $pages as $k => $def ) {
		if ( in_array( $post->post_name, $def['slugs'], true ) ) {
			$key = $k;
			return $key;
		}
	}
	return $key;
}

/** Includes a file from /pd-parts. */
function pd_part( $name ) {
	include get_stylesheet_directory() . '/pd-parts/' . $name . '.php';
}

/* -------------------------------------------------------------------------
 * THEME SETUP
 * ---------------------------------------------------------------------- */

add_action(
	'after_setup_theme',
	function () {
		add_theme_support( 'title-tag' );
	}
);

/** Lets you choose "Padel District: Courts" etc. in a page's Template setting. */
add_filter(
	'theme_page_templates',
	function ( $templates ) {
		foreach ( pd_pages() as $key => $def ) {
			$templates[ 'pd-' . $key ] = 'Padel District: ' . $def['title'];
		}
		return $templates;
	}
);

/* -------------------------------------------------------------------------
 * RENDERING
 * ---------------------------------------------------------------------- */

add_filter(
	'template_include',
	function ( $template ) {
		if ( ! pd_current_key() ) {
			return $template;
		}
		// The parent block theme may have queued its own viewport/title/skip-link output.
		remove_action( 'wp_head', '_block_template_viewport_meta_tag', 0 );
		remove_action( 'wp_head', '_block_template_render_title_tag', 1 );
		if ( ! has_action( 'wp_head', '_wp_render_title_tag' ) ) {
			add_action( 'wp_head', '_wp_render_title_tag', 1 ); // Exactly one <title>.
		}
		remove_action( 'wp_footer', 'the_block_template_skip_link' );
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_block_template_skip_link' );
		return get_stylesheet_directory() . '/pd-template.php';
	},
	999
);

/** Our styles and script, and nothing from the parent theme, on Padel District pages. */
add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! pd_current_key() ) {
			return;
		}
		$dir = get_stylesheet_directory();
		$uri = get_stylesheet_directory_uri();

		wp_enqueue_style( 'padel-district', $uri . '/assets/css/padel-district.css', array(), PD_VERSION . '.' . filemtime( $dir . '/assets/css/padel-district.css' ) );
		wp_enqueue_style( 'padel-district-wp', $uri . '/assets/css/wp-fixes.css', array( 'padel-district' ), PD_VERSION . '.' . filemtime( $dir . '/assets/css/wp-fixes.css' ) );

		wp_enqueue_script( 'padel-district', $uri . '/assets/js/padel-district.js', array(), PD_VERSION . '.' . filemtime( $dir . '/assets/js/padel-district.js' ), array( 'in_footer' => true ) );
		wp_add_inline_script( 'padel-district', 'window.PD_CONFIG=' . wp_json_encode( array( 'whatsappNumber' => preg_replace( '/\D/', '', PD_WHATSAPP_NUMBER ) ) ) . ';', 'before' );
	},
	20
);

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! pd_current_key() ) {
			return;
		}
		$theme_uris = array( get_template_directory_uri(), get_stylesheet_directory_uri() );
		$core       = array( 'global-styles', 'wp-block-library', 'wp-block-library-theme', 'classic-theme-styles', 'core-block-supports', 'wp-webfonts', 'wp-fonts-local' );
		$wp_styles  = wp_styles();
		foreach ( $wp_styles->queue as $handle ) {
			if ( 0 === strpos( $handle, 'padel-district' ) ) {
				continue;
			}
			$src     = isset( $wp_styles->registered[ $handle ] ) ? (string) $wp_styles->registered[ $handle ]->src : '';
			$from_th = false;
			foreach ( $theme_uris as $t ) {
				if ( $src && 0 === strpos( $src, $t ) ) {
					$from_th = true;
				}
			}
			if ( $from_th || in_array( $handle, $core, true ) || 0 === strpos( $handle, 'wp-block-' ) ) {
				wp_dequeue_style( $handle );
			}
		}
		// Block-theme global styles and fonts: not used on these pages.
		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
		remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
		remove_action( 'wp_head', 'wp_print_font_faces', 50 );
		remove_action( 'wp_head', 'wp_enqueue_stored_styles' );
		remove_action( 'wp_footer', 'wp_enqueue_stored_styles', 1 );
		remove_action( 'wp_body_open', 'wp_global_styles_render_svg_filters' );
	},
	100
);

/** Emoji script is not needed and would add weight. */
add_action(
	'wp',
	function () {
		if ( pd_current_key() ) {
			remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
			remove_action( 'wp_print_styles', 'print_emoji_styles' );
			remove_action( 'wp_enqueue_scripts', 'wp_enqueue_emoji_styles' );
		}
	}
);

/* -------------------------------------------------------------------------
 * SEO: title + meta description (skipped if an SEO plugin is active)
 * ---------------------------------------------------------------------- */

function pd_seo_plugin_active() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' );
}

add_filter(
	'pre_get_document_title',
	function ( $title ) {
		$key = pd_current_key();
		if ( $key && ! pd_seo_plugin_active() ) {
			$pages = pd_pages();
			return $pages[ $key ]['seo'];
		}
		return $title;
	},
	20
);

add_action(
	'wp_head',
	function () {
		$key = pd_current_key();
		if ( $key && ! pd_seo_plugin_active() ) {
			$pages = pd_pages();
			echo '<meta name="description" content="' . esc_attr( $pages[ $key ]['desc'] ) . '">' . "\n";
		}
	},
	2
);

/* -------------------------------------------------------------------------
 * CLIENT REVIEW COMMENTS (Hypothesis — free, open source, no trial)
 * Off by default. Turn on by adding to wp-config.php:
 *   define( 'PD_CLIENT_COMMENTS', true );
 * (The Playground staging blueprint does this for you.)
 * ---------------------------------------------------------------------- */

if ( ! defined( 'PD_CLIENT_COMMENTS' ) ) {
	define( 'PD_CLIENT_COMMENTS', false );
}
/** Fixed review address, so comments stay attached even though Playground's own address changes each visit. */
if ( ! defined( 'PD_REVIEW_BASE' ) ) {
	define( 'PD_REVIEW_BASE', 'https://review.padeldistrict.staging' );
}

add_action(
	'wp_head',
	function () {
		$key = pd_current_key();
		if ( ! PD_CLIENT_COMMENTS || ! $key ) {
			return;
		}
		$pages = pd_pages();
		$path  = 'home' === $key ? '/' : '/' . $pages[ $key ]['slugs'][0] . '/';
		echo '<link rel="canonical" href="' . esc_url( PD_REVIEW_BASE . $path ) . '">' . "\n";
		echo '<script>window.hypothesisConfig=function(){return{openSidebar:false,showHighlights:"always",theme:"classic"};};</script>' . "\n";
		echo '<script src="https://hypothes.is/embed.js" async></script>' . "\n";
	},
	3
);

/* Keep the review copy out of search engines. */
add_filter(
	'wp_robots',
	function ( $robots ) {
		if ( PD_CLIENT_COMMENTS && pd_current_key() ) {
			$robots['noindex']  = true;
			$robots['nofollow'] = true;
		}
		return $robots;
	}
);

/* Remove WordPress's own canonical tag on these pages when review comments are on (avoids two canonicals). */
add_action(
	'wp',
	function () {
		if ( PD_CLIENT_COMMENTS && pd_current_key() ) {
			remove_action( 'wp_head', 'rel_canonical' );
		}
	}
);

/* -------------------------------------------------------------------------
 * ADMIN: setup checklist with one-click page creation
 * ---------------------------------------------------------------------- */

add_action(
	'admin_notices',
	function () {
		if ( ! current_user_can( 'edit_pages' ) ) {
			return;
		}
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'themes', 'edit-page' ), true ) ) {
			return;
		}
		$missing = array();
		foreach ( pd_pages() as $key => $def ) {
			if ( ! pd_get_page( $key ) ) {
				$missing[] = $def['title'] . ' (<code>' . esc_html( $def['slugs'][0] ) . '</code>)';
			}
		}
		$home     = pd_get_page( 'home' );
		$home_set = $home && 'page' === get_option( 'show_on_front' ) && (int) get_option( 'page_on_front' ) === (int) $home->ID;
		if ( ! $missing && $home_set ) {
			return;
		}
		$url = wp_nonce_url( admin_url( 'admin-post.php?action=pd_setup' ), 'pd_setup' );
		echo '<div class="notice notice-info"><p><strong>Padel District theme setup</strong></p>';
		if ( $missing ) {
			echo '<p>These pages don’t exist yet (create an empty page with the slug shown): ' . wp_kses_post( implode( ', ', $missing ) ) . '.</p>';
		}
		if ( ! $home_set ) {
			echo '<p>The Home page isn’t set as your homepage yet (Settings → Reading → “A static page”).</p>';
		}
		echo '<p><a class="button button-primary" href="' . esc_url( $url ) . '">Do this for me</a></p></div>';
	}
);

add_action(
	'admin_post_pd_setup',
	function () {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'pd_setup' ) ) {
			wp_die( 'Not allowed.' );
		}
		foreach ( pd_pages() as $key => $def ) {
			if ( ! pd_get_page( $key ) ) {
				// Re-use an unpublished page with the same slug (WordPress ships a draft Privacy Policy).
				foreach ( $def['slugs'] as $slug ) {
					$existing = get_page_by_path( $slug, OBJECT, 'page' );
					if ( $existing && 'trash' !== $existing->post_status ) {
						wp_publish_post( $existing );
						continue 2;
					}
				}
				wp_insert_post(
					array(
						'post_type'    => 'page',
						'post_status'  => 'publish',
						'post_title'   => $def['title'],
						'post_name'    => $def['slugs'][0],
						'post_content' => '',
					)
				);
			}
		}
		$home = get_page_by_path( 'home', OBJECT, 'page' );
		if ( $home ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $home->ID );
		}
		wp_safe_redirect( admin_url( 'edit.php?post_type=page' ) );
		exit;
	}
);
