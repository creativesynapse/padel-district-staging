<?php
/**
 * Full-page template for every Padel District page.
 * Chosen automatically by functions.php (template_include) — the page body comes from /pd-pages/{key}.php.
 *
 * @package padel-district
 */

defined( 'ABSPATH' ) || exit;

$pd_key = pd_current_key();
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'pd-site pd-page-' . $pd_key ); ?>>
<?php
wp_body_open();
pd_part( 'sprite' );
pd_part( 'site-header' );
include get_stylesheet_directory() . '/pd-pages/' . $pd_key . '.php';
pd_part( 'site-footer' );
wp_footer();
?>
</body>
</html>
