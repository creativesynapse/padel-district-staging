/*!
 * Padel District website — front-end behaviour (vanilla JS, no dependencies, ~4 KB minified)
 * Load once per page, at the end of <body> (or with `defer`). Every module checks that its
 * elements exist, so the same file works on every page and on single-section previews.
 *
 * Modules: 1 header state · 2 mobile menu · 3 mobile booking bar · 4 WhatsApp button
 *          5 hero video · 6 gallery lightbox · 7 analytics (dataLayer)
 */
(function () {
  "use strict";

  /* ---------- CONFIG (edit here) ---------- */
  var WHATSAPP_NUMBER = (window.PD_CONFIG && window.PD_CONFIG.whatsappNumber) || "";  // set PD_WHATSAPP_NUMBER in functions.php   // country code + number, digits only, e.g. "60123456789". Empty = "coming soon" panel.
  var WHATSAPP_TEXT = "Hi Padel District, I have a question about booking a court.";
  var DESKTOP_NAV_MIN = 1200; // px — must match the CSS breakpoint for .primary-nav

  var $ = function (id) { return document.getElementById(id); };
  var header = $("site-header");
  var hero = document.querySelector(".hero");
  var menuOpen = false;

  /* 1. HEADER: transparent over the homepage hero until the visitor scrolls 40 px */
  function updateHeader() {
    if (!header) return;
    header.classList.toggle("is-over", !!hero && window.scrollY < 40 && !menuOpen);
  }
  window.addEventListener("scroll", updateHeader, { passive: true });
  updateHeader();

  /* 2. MOBILE MENU (below 1200 px): aria-expanded, Esc to close, page behind made inert */
  var toggle = $("menu-toggle"), menu = $("mobile-menu");
  if (toggle && menu) {
    var inertTargets = [$("main"), $("site-footer"), $("book-bar"), $("wa")];
    /* Scroll lock that works on iOS/Android and inside iframes (e.g. WordPress Playground):
       the page is pinned in place with position:fixed and restored on close. */
    var lockY = 0, bodyStyle = document.body.style;
    var lockScroll = function (on) {
      if (on) {
        lockY = window.pageYOffset || document.documentElement.scrollTop || 0;
        bodyStyle.position = "fixed"; bodyStyle.top = -lockY + "px";
        bodyStyle.left = "0"; bodyStyle.right = "0"; bodyStyle.width = "100%";
      } else {
        bodyStyle.position = ""; bodyStyle.top = ""; bodyStyle.left = ""; bodyStyle.right = ""; bodyStyle.width = "";
        var html = document.documentElement, prev = html.style.scrollBehavior;
        html.style.scrollBehavior = "auto";
        window.scrollTo(0, lockY);
        html.style.scrollBehavior = prev;
      }
    };
    var setMenu = function (open) {
      if (open === menuOpen) return;
      menuOpen = open;
      lockScroll(open);
      menu.hidden = !open;
      toggle.setAttribute("aria-expanded", String(open));
      toggle.firstChild.nodeValue = open ? "Close " : "Menu ";
      document.body.classList.toggle("menu-open", open);
      if (header) header.classList.toggle("menu-on", open);
      inertTargets.forEach(function (t) { if (t) { if (open) t.setAttribute("inert", ""); else t.removeAttribute("inert"); } });
      updateHeader();
      if (open) { var first = menu.querySelector("a"); if (first) { try { first.focus({ preventScroll: true }); } catch (err) { first.focus(); } } }
    };
    toggle.addEventListener("click", function () { setMenu(!menuOpen); });
    menu.addEventListener("click", function (e) { if (e.target.closest("a")) setMenu(false); });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape" && menuOpen) { setMenu(false); toggle.focus(); } });
    var mq = window.matchMedia("(min-width:" + DESKTOP_NAV_MIN + "px)");
    var onMq = function (e) { if (e.matches && menuOpen) setMenu(false); };
    if (mq.addEventListener) mq.addEventListener("change", onMq); else if (mq.addListener) mq.addListener(onMq);
  }

  /* 3. MOBILE BOOKING BAR (below 1024 px): tucked away while the hero's own booking button is on screen.
        body.bar-on lifts the WhatsApp button above the bar. */
  var bar = $("book-bar"), heroCta = document.querySelector(".hero .btn-book");
  if (bar) {
    if (heroCta && "IntersectionObserver" in window) {
      new IntersectionObserver(function (entries) {
        var tucked = entries[0].isIntersecting;
        bar.classList.toggle("is-tucked", tucked);
        document.body.classList.toggle("bar-on", !tucked);
      }, { threshold: 0.5 }).observe(heroCta);
    } else {
      document.body.classList.add("bar-on");
    }
  }

  /* 4. WHATSAPP BUTTON: opens a wa.me chat once WHATSAPP_NUMBER is set; until then a small panel */
  var waBtn = $("wa-btn"), waPop = $("wa-pop"), waClose = $("wa-close");
  if (waBtn) {
    if (WHATSAPP_NUMBER) {
      waBtn.href = "https://wa.me/" + WHATSAPP_NUMBER + "?text=" + encodeURIComponent(WHATSAPP_TEXT);
      waBtn.target = "_blank"; waBtn.rel = "noopener";
      waBtn.removeAttribute("aria-controls"); waBtn.removeAttribute("aria-expanded");
      if (waPop) waPop.remove();
    } else if (waPop) {
      var setWa = function (open) { waPop.hidden = !open; waBtn.setAttribute("aria-expanded", String(open)); if (open && waClose) waClose.focus(); };
      waBtn.setAttribute("role", "button");
      waBtn.addEventListener("click", function (e) { e.preventDefault(); setWa(waPop.hidden); });
      if (waClose) waClose.addEventListener("click", function () { setWa(false); waBtn.focus(); });
      document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !waPop.hidden) { setWa(false); waBtn.focus(); } });
      document.addEventListener("click", function (e) { if (!waPop.hidden && !e.target.closest("#wa")) setWa(false); });
    }
  }

  /* 5. HERO VIDEO: always plays, muted and looping, on every device.
     Phones (under 768 px) get the portrait version (data-src-mobile). */
  var video = $("hero-video");
  if (video && video.dataset.src) {
    var narrow = window.matchMedia("(max-width:767px)").matches;
    if (video.dataset.poster) video.poster = video.dataset.poster;
    video.muted = true; video.loop = true; video.autoplay = true;
    video.setAttribute("playsinline", ""); video.setAttribute("webkit-playsinline", "");
    video.src = (narrow && video.dataset.srcMobile) ? video.dataset.srcMobile : video.dataset.src;
    var startVideo = function () {
      var p = video.play();
      if (p && p.then) p.then(function () { video.classList.add("is-playing"); }).catch(function () {});
    };
    video.addEventListener("playing", function () { video.classList.add("is-playing"); });
    startVideo();
    /* Some phones block autoplay until the visitor first touches the page: try again then. */
    var retry = function () { if (video.paused) startVideo(); };
    ["touchstart", "click", "scroll"].forEach(function (ev) { window.addEventListener(ev, retry, { once: true, passive: true }); });
    /* Resume if the browser paused it (e.g. after switching apps or tabs). */
    document.addEventListener("visibilitychange", function () { if (!document.hidden && video.paused) startVideo(); });
  }

  /* 5b. GALLERY COUNTER (phones: the gallery is a swipeable row) */
  var gal = document.querySelector(".gallery"), gcount = document.querySelector(".g-swipe .g-count");
  if (gal && gcount) {
    var items = gal.children, tick = false;
    var updateCount = function () {
      tick = false;
      var x = gal.scrollLeft, best = 0, bestD = Infinity;
      for (var k = 0; k < items.length; k++) { var d = Math.abs(items[k].offsetLeft - gal.offsetLeft - x); if (d < bestD) { bestD = d; best = k; } }
      if (gal.scrollLeft + gal.clientWidth >= gal.scrollWidth - 4) best = items.length - 1;
      gcount.textContent = (best + 1) + " / " + items.length;
    };
    gal.addEventListener("scroll", function () { if (!tick) { tick = true; requestAnimationFrame(updateCount); } }, { passive: true });
    updateCount();
  }

  /* 6. GALLERY LIGHTBOX: native <dialog>, arrow keys, Esc, focus returns to the opened image */
  var items = [].slice.call(document.querySelectorAll(".g-item")), dlg = $("lightbox");
  if (items.length && dlg) {
    var lbImg = $("lb-img"), lbTitle = $("lb-title"), lbCount = $("lb-count"), idx = 0, opener = null;
    var openLb = function (i) {
      idx = (i + items.length) % items.length;
      var it = items[idx];
      lbImg.src = it.dataset.full; lbImg.alt = it.dataset.alt; lbTitle.textContent = it.dataset.label;
      lbCount.textContent = (idx + 1) + " / " + items.length;
      if (!dlg.open) { if (dlg.showModal) dlg.showModal(); else dlg.setAttribute("open", ""); }
    };
    var closeLb = function () { if (dlg.close) dlg.close(); else dlg.removeAttribute("open"); };
    items.forEach(function (it, i) { it.addEventListener("click", function () { opener = it; openLb(i); }); });
    $("lb-prev").addEventListener("click", function () { openLb(idx - 1); });
    $("lb-next").addEventListener("click", function () { openLb(idx + 1); });
    $("lb-close").addEventListener("click", closeLb);
    dlg.addEventListener("click", function (e) { if (e.target === dlg) closeLb(); });
    dlg.addEventListener("keydown", function (e) { if (e.key === "ArrowLeft") openLb(idx - 1); if (e.key === "ArrowRight") openLb(idx + 1); });
    dlg.addEventListener("close", function () { if (opener) opener.focus(); });
  }

  /* 7. ANALYTICS: any element with data-track pushes an event to window.dataLayer for GTM.
        book_court_click is a click to Playtomic, never a completed booking. */
  window.dataLayer = window.dataLayer || [];
  document.addEventListener("click", function (e) {
    var a = e.target.closest("[data-track]"); if (!a) return;
    var ev = { event: a.dataset.track, page: location.pathname };
    if (a.dataset.cta) ev.cta_location = a.dataset.cta;
    if (a.dataset.provider) ev.provider = a.dataset.provider;
    if (a.href && a.getAttribute("href") !== "#") ev.link_url = a.href;
    window.dataLayer.push(ev);
  });
  document.querySelectorAll(".faq details").forEach(function (d) {
    d.addEventListener("toggle", function () {
      if (d.open) { var s = d.querySelector("summary"); window.dataLayer.push({ event: "faq_interaction", faq_question: (s ? s.textContent : "").trim(), page: location.pathname }); }
    });
  });
})();
