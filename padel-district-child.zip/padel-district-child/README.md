# Padel District — WordPress child theme

## Install
1. Appearance → Themes → Add New → Upload Theme → choose `padel-district-child.zip` → Install → Activate.
   (Parent: Twenty Twenty-Five, which ships with WordPress. Keep it installed; it doesn't need to be active.)
2. Pages → Add New: create these pages, leave them empty, publish:

| Page title     | Slug             |
| -------------- | ---------------- |
| Home           | `home`           |
| Courts         | `courts`         |
| About          | `about`          |
| Food & Drinks  | `food-drinks`    |
| Visit Us       | `visit`          |
| FAQ            | `faq`            |
| Privacy Policy | `privacy-policy` |
| Website Terms  | `terms`          |

   Shortcut: after activating, a "Padel District theme setup" notice appears on the Dashboard / Pages screen. "Do this for me" creates any missing pages and sets Home as the homepage.
3. Settings → Reading → Your homepage displays → A static page → Homepage: **Home**.
4. Settings → Permalinks → "Post name" (so URLs look like /courts/).

Any other slug works too: open the page, and in the Template setting choose "Padel District: Courts" (etc.).

## Editing
- Page content: `pd-pages/*.php` (one file per page). The WordPress editor content is not used.
- Header / footer / mobile booking bar / WhatsApp button: `pd-parts/site-header.php`, `pd-parts/site-footer.php`.
- Styles: `assets/css/padel-district.css` (design tokens at the top) and `assets/css/wp-fixes.css`.
- WhatsApp number: `PD_WHATSAPP_NUMBER` at the top of `functions.php` (digits with country code, e.g. `60123456789`).
- SEO titles and descriptions: `pd_pages()` in `functions.php`. If Yoast, Rank Math, AIOSEO, SEOPress or The SEO Framework is active, the theme steps aside and the plugin controls them.

## Tested
WordPress 7.2 with Twenty Twenty-Five (and a classic parent), at 320, 360, 375, 390, 414, 480, 600, 768, 820, 1024, 1180, 1280, 1366, 1440 and 1920 px plus phone landscape: no horizontal scroll, no console errors, all images load; menu, booking bar, WhatsApp panel, lightbox and admin bar offset all work.
