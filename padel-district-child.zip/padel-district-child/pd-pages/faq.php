<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head">
    <div class="wrap stack-3">
      <p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>FAQ</span></p>
      <h1 class="h-xl">Good to know.</h1>
      <p class="lede">Booking, playing and getting here. If your question isn’t here, message us on Instagram.</p>
    </div>
  </header>
  <section class="section">
    <div class="wrap grid faq-grid">
      <div class="q-head stack-3">
        <p class="eyebrow">Jump to</p>
        <ul class="stack-2" style="font-weight:600">
          <li><a class="tlink" href="#faq-booking">Booking</a></li>
          <li><a class="tlink" href="#faq-playing">Playing</a></li>
          <li><a class="tlink" href="#faq-visiting">Visiting</a></li>
          <li><a class="tlink" href="#faq-more">Food, drinks &amp; contact</a></li>
        </ul>
        <a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="faq_page"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
      </div>
      <div class="q-list">
        <div class="faq-group" id="faq-booking"><h2>Booking</h2><div class="faq"><details name="faq-booking"><summary>How do I book a court? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Book on Playtomic, on the web or in the app. Open Padel District, pick a time and a court, and confirm. <a href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="faq_answer">Book a Court with Playtomic →</a></p></div></details>
<details name="faq-booking"><summary>Where do I find my booking? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>In the Playtomic app or your Playtomic account, under your bookings.</p></div></details>
<details name="faq-booking"><summary>Can I cancel or change my booking? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Changes and cancellations are handled in Playtomic, under the booking terms shown when you book. Open your booking in the Playtomic app to see your options.</p></div></details></div></div>
<div class="faq-group" id="faq-playing"><h2>Playing</h2><div class="faq"><details name="faq-playing"><summary>Is Padel District suitable for beginners? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Yes. All seven courts are open to every level, and you book them the same way as everyone else.</p></div></details>
<details name="faq-playing"><summary>What is padel? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>A racket sport usually played in pairs on an enclosed 20 × 10 m court. Serves are underarm and the ball can come off the glass walls, so rallies keep going and most people pick it up fast.</p></div></details>
<details name="faq-playing"><summary>Do I need to bring my own racket? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>No. Rackets and balls are available at the District. <span class="pending">To confirm: rental or borrowing terms and any fee</span></p></div></details>
<details name="faq-playing"><summary>How many courts are available? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Seven indoor, panoramic doubles courts: Padel 01–06 and Centre Court.</p></div></details></div></div>
<div class="faq-group" id="faq-visiting"><h2>Visiting</h2><div class="faq"><details name="faq-visiting"><summary>What are your opening hours? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>We’re open every day from 8:00 AM to 12:00 AM (midnight).</p></div></details>
<details name="faq-visiting"><summary>Where is Padel District located? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>227, Jalan Kenanga, Kampung Sungai Kayu Ara, 47400 Petaling Jaya, Selangor. <a href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="faq_answer">Get directions →</a></p></div></details>
<details name="faq-visiting"><summary>Where can I find parking information? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Free parking is available on site.</p></div></details>
<details name="faq-visiting"><summary>What time should I arrive? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Give yourself time to check in and warm up before your slot starts. <span class="pending">To confirm: recommended arrival time</span></p></div></details>
<details name="faq-visiting"><summary>Where do I go when I arrive? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Courts are signed Padel 01–06 and Centre Court. <span class="pending">To confirm: entrance and check-in point</span></p></div></details></div></div>
<div class="faq-group" id="faq-more"><h2>Food, drinks &amp; contact</h2><div class="faq"><details name="faq-more"><summary>Are food and drinks available? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Food and drinks are coming soon. For now, there’s a water dispenser on site.</p></div></details>
<details name="faq-more"><summary>How do I contact the team? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p><span class="pending">To confirm: phone, WhatsApp or email</span> You can also message us on Instagram at <a href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="faq_answer">@padeldistrict.my</a>.</p></div></details></div></div>
      </div>
    </div>
  </section>
</main>
