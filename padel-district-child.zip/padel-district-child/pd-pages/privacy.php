<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head"><div class="wrap stack-3"><p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>Privacy Policy</span></p><h1 class="h-xl">Privacy Policy</h1><p class="lede"><span class="pending">To be supplied by Padel District: policy text, including analytics and Meta Pixel consent</span></p></div></header>
</main>
