<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head"><div class="wrap stack-3"><p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>Website Terms</span></p><h1 class="h-xl">Website Terms</h1><p class="lede"><span class="pending">To be supplied by Padel District: website terms of use</span></p><p>Court bookings are made on Playtomic and follow the terms shown there when you book.</p></div></header>
</main>
