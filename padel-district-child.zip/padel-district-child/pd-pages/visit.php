<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head">
    <div class="wrap stack-3">
      <p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>Visit Us</span></p>
      <h1 class="h-xl">Find your way to the District.</h1>
      <p class="lede">Kayu Ara, Petaling Jaya. Open every day from 7:00 AM to midnight.</p>
    </div>
  </header>
  <section class="section" aria-labelledby="visit-addr">
    <div class="wrap grid loc-grid">
      <div class="l-copy stack-4">
        <h2 class="h-m" id="visit-addr">Address</h2>
        <address class="addr">227, Jalan Kenanga,<br>Kampung Sungai Kayu Ara,<br>47400 Petaling Jaya,<br>Selangor, Malaysia.</address>
        <div class="actions">
          <a class="btn btn-ink" href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="visit_page">Get Directions on Google Maps <span class="arr" aria-hidden="true">→</span></a>
          <a class="btn btn-line" href="https://waze.com/ul/hw283b1zxq" target="_blank" rel="noopener" data-track="directions_click" data-provider="waze" data-cta="visit_page">Navigate with Waze <span class="arr" aria-hidden="true">→</span></a>
        </div>
        <dl class="dl">
          <div><dt>Hours</dt><dd class="num">Daily, 7:00 AM – 12:00 AM</dd></div>
          <div><dt>Booking</dt><dd><a class="tlink" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="visit_page_list">Book on Playtomic <span class="arr" aria-hidden="true">→</span></a></dd></div>
          <div><dt>Parking</dt><dd>Free parking on site, as listed on Playtomic. <span class="pending">To confirm: where to park</span></dd></div>
          <div><dt>Arriving</dt><dd><span class="pending">To confirm: entrance and check-in directions</span></dd></div>
          <div><dt>Contact</dt><dd><span class="pending">To confirm: phone, WhatsApp or email</span> Instagram: <a class="tlink" href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="visit_page">@padeldistrict.my</a></dd></div>
        </dl>
      </div>
      <div class="l-map stack-3">
        <div class="map-facade" role="group" aria-label="Location of Padel District">
  <svg class="plan" viewBox="0 0 600 450" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <g stroke="#1F2724" stroke-opacity=".12" stroke-width="1"><line x1="0" y1="0" x2="0" y2="450"/><line x1="50" y1="0" x2="50" y2="450"/><line x1="100" y1="0" x2="100" y2="450"/><line x1="150" y1="0" x2="150" y2="450"/><line x1="200" y1="0" x2="200" y2="450"/><line x1="250" y1="0" x2="250" y2="450"/><line x1="300" y1="0" x2="300" y2="450"/><line x1="350" y1="0" x2="350" y2="450"/><line x1="400" y1="0" x2="400" y2="450"/><line x1="450" y1="0" x2="450" y2="450"/><line x1="500" y1="0" x2="500" y2="450"/><line x1="550" y1="0" x2="550" y2="450"/><line x1="600" y1="0" x2="600" y2="450"/><line x1="0" y1="0" x2="600" y2="0"/><line x1="0" y1="50" x2="600" y2="50"/><line x1="0" y1="100" x2="600" y2="100"/><line x1="0" y1="150" x2="600" y2="150"/><line x1="0" y1="200" x2="600" y2="200"/><line x1="0" y1="250" x2="600" y2="250"/><line x1="0" y1="300" x2="600" y2="300"/><line x1="0" y1="350" x2="600" y2="350"/><line x1="0" y1="400" x2="600" y2="400"/><line x1="0" y1="450" x2="600" y2="450"/></g>
    <g stroke="#1F2724" stroke-opacity=".45" stroke-width="1" fill="none">
      <line x1="300" y1="0" x2="300" y2="450" stroke-dasharray="3 5"/><line x1="0" y1="225" x2="600" y2="225" stroke-dasharray="3 5"/>
      <rect x="200" y="150" width="200" height="150"/><rect x="250" y="187.5" width="100" height="75"/>
    </g>
  </svg>
  <span class="coords">3.1308° N · 101.6120° E</span>
  <div class="map-pin" aria-hidden="true"><span class="pin-head"><svg viewBox="0 0 650 500"><use href="#pd-symbol"/></svg></span><span class="pin-stem"></span><span class="pin-dot"></span></div>
  <div class="map-card"><p>The interactive Google Map loads here on the live site when tapped, so it never slows the page.</p>
    <a class="btn btn-ink btn-sm" href="https://www.google.com/maps/search/?api=1&amp;query=Padel%20District%2C%20227%20Jalan%20Kenanga%2C%20Petaling%20Jaya&amp;query_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="map_card">Open in Google Maps <span class="arr" aria-hidden="true">→</span></a></div>
</main>
