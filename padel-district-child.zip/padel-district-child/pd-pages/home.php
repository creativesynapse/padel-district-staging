<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
<!-- ===== SECTION 01 · Hero ===== -->
<section class="hero" aria-labelledby="hero-title">
    <div class="hero-media">
      <img src="<?php echo esc_url( pd_img( 'pd-hero-1920.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-hero-960.webp' ) ); ?> 960w, <?php echo esc_url( pd_img( 'pd-hero-1920.webp' ) ); ?> 1920w" sizes="100vw" width="1920" height="1080" alt="Aerial view over the Padel District courts, blue and green courts under the steel roof" fetchpriority="high">
      <video class="hero-video" id="hero-video" muted playsinline loop autoplay preload="auto" aria-hidden="true" data-src="<?php echo esc_url( pd_img( 'pd-hero.mp4' ) ); ?>" data-src-mobile="<?php echo esc_url( pd_img( 'pd-hero-mobile.mp4' ) ); ?>" data-poster="<?php echo esc_url( pd_img( 'pd-hero-1920.webp' ) ); ?>"></video>
    </div>
    <div class="wrap hero-content">
      <p class="eyebrow">Kayu Ara, Petaling Jaya</p>
      <h1 id="hero-title">Find your court.</h1>
      <p class="hero-line">Seven courts. One District. Grounds for play.</p>
      <div class="actions">
        <a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="hero"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
        <a class="tlink" href="<?php echo esc_url( pd_url( 'home' ) . '#explore' ); ?>" data-scroll="explore">Explore the District <span class="arr" aria-hidden="true">↓</span></a>
      </div>
    </div>
    <span class="hero-net" aria-hidden="true"></span>
  </section>

<!-- ===== SECTION 02 · Quick info strip ===== -->
<section class="info" aria-labelledby="info-title">
    <div class="wrap">
      <div class="info-head">
        <h2 id="info-title">Everything you need to get playing.</h2>
        <a class="tlink" href="<?php echo esc_url( pd_url( 'visit' ) ); ?>">Plan your visit <span class="arr" aria-hidden="true">→</span></a>
      </div>
      <dl class="info-cells">
        <div class="info-cell"><dt>Courts</dt><span class="big">07</span><dd>Centre Court + Padel 01–06</dd></div>
        <div class="info-cell"><dt>Open daily</dt><span class="big">7AM–12AM</span><dd>7:00 AM – 12:00 AM, every day</dd></div>
        <div class="info-cell"><dt>Location</dt><span class="big">Kayu Ara</span><dd>Petaling Jaya, Selangor</dd></div>
        <div class="info-cell"><dt>Booking</dt><span class="big pt-big"><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg></span><dd><a class="tlink" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="info_strip">Book a Court with Playtomic <span class="arr" aria-hidden="true">→</span></a></dd></div>
      </dl>
    </div>
  </section>

<!-- ===== SECTION 03 · Courts ===== -->
<section class="section band-stone" id="explore" aria-labelledby="courts-title">
    <div class="wrap grid courts-grid">
      <div class="c-copy stack-3">
        <p class="eyebrow">The courts</p>
        <h2 class="h-xl" id="courts-title">Seven courts. One District.</h2>
        <p class="lede">Find your next game at Padel District. Seven courts, a place to meet and plenty of reasons to come back.</p>
        <ul class="facts">
          <li><span>Layout</span><span>Centre Court + Padel 01–06</span></li>
          <li><span>Every court</span><span>Indoor · panoramic glass · doubles</span></li>
          <li><span>Hours</span><span class="num">Daily, 7:00 AM – 12:00 AM</span></li>
          <li><span>On site</span><span>Rackets &amp; balls, towels, water</span></li>
        </ul>
        <div class="actions">
          <a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="courts_section"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
          <a class="tlink" href="<?php echo esc_url( pd_url( 'courts' ) ); ?>">Court details <span class="arr" aria-hidden="true">→</span></a>
        </div>
      </div>
      <div class="c-plan">
        <figure class="plan"><svg viewBox="-1 -5.5 58.5 79" role="img" aria-label="Court layout: Centre Court on the left; Padel 01 to 06 stacked on the right"><text x="10" y="29.05" text-anchor="middle" font-size="1.9" font-weight="600" letter-spacing=".22" fill="#1F2724">CENTRE COURT</text><text x="40" y="-2.4" text-anchor="middle" font-size="1.9" font-weight="600" letter-spacing=".22" fill="#1F2724">PADEL 01–06</text><g transform="translate(0 31.25)"><rect x="0" y="0" width="20" height="10" fill="#1F2724" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#F1F2EA" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#F1F2EA" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g></g><g transform="translate(30 0.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">01</text></g><g transform="translate(30 12.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">02</text></g><g transform="translate(30 25.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">03</text></g><g transform="translate(30 37.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">04</text></g><g transform="translate(30 50.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">05</text></g><g transform="translate(30 62.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">06</text></g></svg><figcaption>Indicative plan of the District’s seven courts, each 20 × 10 m. Spacing not to scale.</figcaption></figure>
      </div>
      <div class="media ratio-32 c-photo">
        <img src="<?php echo esc_url( pd_img( 'pd-courts-teaser-1600.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-courts-teaser-800.webp' ) ); ?> 800w, <?php echo esc_url( pd_img( 'pd-courts-teaser-1600.webp' ) ); ?> 1600w" sizes="(min-width:1024px) 40vw, 100vw" width="1600" height="1066" loading="lazy" alt="A doubles game on a blue court, with the lounge and green courts behind">
      </div>
    </div>
  </section>

<!-- ===== SECTION 04 · How to book ===== -->
<section class="section band-ink on-dark howto" id="how-to-book" aria-labelledby="book-title">
    <div class="wrap">
      <div class="stack-3" style="margin-bottom:var(--sp-5)">
        <p class="eyebrow">How to book</p>
        <h2 class="h-xl" id="book-title" style="max-width:11em">Your next game, a few clicks away.</h2>
      </div>
      <ol class="steps">
        <li class="step">
          <div class="s-top"><span class="s-num">01</span><svg class="icon" aria-hidden="true"><use href="#i-cal"/></svg></div>
          <span class="s-net" aria-hidden="true"></span>
          <div class="s-body"><h3>Find your time</h3><p>Open Padel District on Playtomic and see the times you can book.</p></div>
        </li>
        <li class="step">
          <div class="s-top"><span class="s-num">02</span><svg class="icon" aria-hidden="true"><use href="#i-court"/></svg></div>
          <span class="s-net" aria-hidden="true"></span>
          <div class="s-body"><h3>Book your court</h3><p>Choose your court and complete your booking on Playtomic.</p></div>
        </li>
        <li class="step">
          <div class="s-top"><span class="s-num">03</span><svg class="icon" aria-hidden="true"><use href="#i-arrive"/></svg></div>
          <span class="s-net" aria-hidden="true"></span>
          <div class="s-body"><h3>See you at the District</h3><p>Come by for your game. Rackets and balls are here if you need them.</p></div>
        </li>
      </ol>
      <div class="book-note">
        <p>Court availability, prices and booking conditions are shown and handled by Playtomic. You’ll see the current terms before you confirm.</p>
        <a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="how_to_book"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
      </div>
    </div>
  </section>

<!-- ===== SECTION 05 · Gallery ===== -->
<section class="section" aria-labelledby="gallery-title">
    <div class="wrap">
      <div class="rev-head">
        <div class="stack-3">
          <p class="eyebrow">Gallery</p>
          <h2 class="h-xl" id="gallery-title">A closer look at the District.</h2>
        </div>
        <p class="muted" style="max-width:26em;font-size:var(--fs-s)">Courts, games and the moments between them, all under one roof in Kayu Ara.</p>
      </div>
      <div class="gallery" id="gallery">
        <button class="g-item g1" type="button" data-full="<?php echo esc_url( pd_img( 'pd-gameplay-full.webp' ) ); ?>" data-alt="Player hitting a forehand on a blue indoor court" data-label="Gameplay"><img src="<?php echo esc_url( pd_img( 'pd-gameplay-1200.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-gameplay-600.webp' ) ); ?> 600w, <?php echo esc_url( pd_img( 'pd-gameplay-1200.webp' ) ); ?> 1200w" sizes="(min-width:900px) 55vw, 100vw" loading="lazy" alt="Player hitting a forehand on a blue indoor court" style="object-position:50% 58%"><span class="g-cap">Gameplay</span></button>
        <button class="g-item g2" type="button" data-full="<?php echo esc_url( pd_img( 'pd-venue-full.webp' ) ); ?>" data-alt="Players between games on a blue court under the steel roof, Padel District banners behind" data-label="The courts"><img src="<?php echo esc_url( pd_img( 'pd-venue-800.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-venue-800.webp' ) ); ?> 800w, <?php echo esc_url( pd_img( 'pd-venue-1400.webp' ) ); ?> 1400w" sizes="(min-width:900px) 40vw, 100vw" loading="lazy" alt="Players between games on a blue court under the steel roof, Padel District banners behind"><span class="g-cap">The courts</span></button>
        <button class="g-item g3" type="button" data-full="<?php echo esc_url( pd_img( 'pd-backhand-full.webp' ) ); ?>" data-alt="Player playing a low backhand on a green indoor court" data-label="Game on"><img src="<?php echo esc_url( pd_img( 'pd-backhand-800.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-backhand-800.webp' ) ); ?> 800w, <?php echo esc_url( pd_img( 'pd-backhand-1400.webp' ) ); ?> 1400w" sizes="(min-width:900px) 40vw, 100vw" loading="lazy" alt="Player playing a low backhand on a green indoor court"><span class="g-cap">Game on</span></button>
        <div class="shot g4"><span class="shot-label">Photo to come</span><span class="shot-title">Building exterior &amp; entrance</span></div>
        <button class="g-item g5" type="button" data-full="<?php echo esc_url( pd_img( 'life-1100.webp' ) ); ?>" data-alt="Racket, balls, towel and water bottle laid out on a concrete floor" data-label="Kit on site"><img src="<?php echo esc_url( pd_img( 'life-600.webp' ) ); ?>" loading="lazy" alt="Racket, balls, towel and water bottle laid out on a concrete floor" style="object-position:50% 40%"><span class="asset-tag">AI visualisation</span><span class="g-cap">Kit on site</span></button>
        <div class="shot g6"><span class="shot-label">Photo to come</span><span class="shot-title">Reception &amp; amenities</span></div>
      </div>
    </div>
  </section>

<!-- ===== SECTION 06 · Google reviews ===== -->
<section class="section band-stone" id="reviews" aria-labelledby="reviews-title">
    <div class="wrap">
      <div class="rev-head">
        <div class="stack-3">
          <p class="eyebrow">Google reviews</p>
          <h2 class="h-xl" id="reviews-title">What players are saying.</h2>
        </div>
        <a class="rating-box" href="https://search.google.com/local/reviews?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="rating_box" aria-label="Rated 5.0 out of 5 from 8 Google reviews. Read them on Google">
          <span class="score num">5.0</span>
          <span class="rb-meta">
            <span class="stars is-filled" aria-hidden="true"><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg></span>
            <span class="rb-count">8 reviews on Google <span class="arr" aria-hidden="true">↗</span></span>
          </span>
        </a>
      </div>
      <div class="reviews">
        <article class="review"><div class="r-top"><span class="stars is-filled" role="img" aria-label="5 out of 5 stars"><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg></span><span class="g-attr">Google</span></div><blockquote><p>“A well-planned padel club worth checking out!”</p></blockquote><div class="r-who"><span class="avatar" aria-hidden="true">T</span><div><b>Tejas chouhan</b><small>2 weeks ago · Local Guide</small></div></div><a class="tlink r-link" href="https://search.google.com/local/reviews?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="review_card">Read on Google <span class="arr" aria-hidden="true">↗</span></a></article>
<article class="review"><div class="r-top"><span class="stars is-filled" role="img" aria-label="5 out of 5 stars"><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg></span><span class="g-attr">Google</span></div><blockquote><p>“…very comfy setup, and pro-grade courts. Well done”</p></blockquote><div class="r-who"><span class="avatar" aria-hidden="true">G</span><div><b>Gan Zhe Jun</b><small>3 days ago · Local Guide</small></div></div><a class="tlink r-link" href="https://search.google.com/local/reviews?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="review_card">Read on Google <span class="arr" aria-hidden="true">↗</span></a></article>
<article class="review"><div class="r-top"><span class="stars is-filled" role="img" aria-label="5 out of 5 stars"><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg><svg><use href="#i-star"/></svg></span><span class="g-attr">Google</span></div><blockquote><p>“Nice padel spot! Good number of parking available. Very spacious”</p></blockquote><div class="r-who"><span class="avatar" aria-hidden="true">S</span><div><b>Sab Tee</b><small>3 weeks ago · Local Guide</small></div></div><a class="tlink r-link" href="https://search.google.com/local/reviews?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="review_card">Read on Google <span class="arr" aria-hidden="true">↗</span></a></article>
      </div>
      <div class="rev-foot">
        <p class="muted">Excerpts from Padel District’s Google reviews, as of 15 Nov 2026. On the live site this section updates from Google automatically.</p>
        <div class="actions">
          <a class="btn btn-ink" href="https://search.google.com/local/reviews?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="reviews_section">See All Reviews on Google <span class="arr" aria-hidden="true">↗</span></a>
          <a class="tlink" href="https://search.google.com/local/writereview?placeid=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="review_source_click" data-cta="write_review">Played here? Leave a review <span class="arr" aria-hidden="true">↗</span></a>
        </div>
      </div>
    </div>
  </section>

<!-- ===== SECTION 07 · Food & Drinks teaser ===== -->
<section class="section band-ink fnb on-dark" aria-labelledby="fnb-title">
    <div class="wrap grid fnb-grid">
      <div class="fb-copy stack-3">
        <span class="soon">Coming soon</span>
        <h2 class="h-xl" id="fnb-title">More to come at the District.</h2>
        <p class="lede">We’re making room for more than just the game. Food, drinks and new reasons to stay are on the way.</p>
        <div class="actions">
          <a class="btn btn-line" href="<?php echo esc_url( pd_url( 'food-drinks' ) ); ?>">Food &amp; Drinks <span class="arr" aria-hidden="true">→</span></a>
          <a class="tlink" href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="fnb_section">Follow @padeldistrict.my for news <span class="arr" aria-hidden="true">→</span></a>
        </div>
      </div>
      <div class="fb-art" aria-hidden="true">
        <svg viewBox="0 0 520 300" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="1" y="1" width="518" height="298"/>
          <line x1="1" y1="150" x2="519" y2="150"/>
          <line x1="260" y1="1" x2="260" y2="299" stroke-dasharray="4 6"/>
          <rect x="40" y="40" width="180" height="70"/>
          <rect x="300" y="190" width="180" height="70"/>
          <text x="48" y="80" fill="currentColor" stroke="none" font-family="Helvetica Neue, Arial, sans-serif" font-size="13" font-weight="600" letter-spacing="1.6">FOOD</text>
          <text x="308" y="230" fill="currentColor" stroke="none" font-family="Helvetica Neue, Arial, sans-serif" font-size="13" font-weight="600" letter-spacing="1.6">DRINKS</text>
        </svg>
      </div>
    </div>
  </section>

<!-- ===== SECTION 08 · Locate us ===== -->
<section class="section" id="locate" aria-labelledby="locate-title">
    <div class="wrap grid loc-grid">
      <div class="l-copy stack-4">
        <div class="stack-3">
          <p class="eyebrow">Locate us</p>
          <h2 class="h-xl" id="locate-title">Find your way to the District.</h2>
        </div>
        <address class="addr">227, Jalan Kenanga,<br>Kampung Sungai Kayu Ara,<br>47400 Petaling Jaya,<br>Selangor, Malaysia.</address>
        <dl class="dl">
          <div><dt>Hours</dt><dd class="num">Daily, 7:00 AM – 12:00 AM</dd></div>
          <div><dt>Parking</dt><dd>Free parking on site, as listed on Playtomic. <span class="pending">To confirm: where to park</span></dd></div>
          <div><dt>Arriving</dt><dd><span class="pending">To confirm: entrance and check-in directions</span></dd></div>
        </dl>
        <div class="actions">
          <a class="btn btn-ink" href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="locate_section">Get Directions on Google Maps <span class="arr" aria-hidden="true">→</span></a>
          <a class="btn btn-line" href="https://waze.com/ul/hw283b1zxq" target="_blank" rel="noopener" data-track="directions_click" data-provider="waze" data-cta="locate_section">Navigate with Waze <span class="arr" aria-hidden="true">→</span></a>
        </div>
      </div>
      <div class="l-map">
        <div class="map-facade" role="group" aria-label="Location of Padel District">
  <svg class="plan" viewBox="0 0 600 450" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
    <g stroke="#1F2724" stroke-opacity=".12" stroke-width="1"><line x1="0" y1="0" x2="0" y2="450"/><line x1="50" y1="0" x2="50" y2="450"/><line x1="100" y1="0" x2="100" y2="450"/><line x1="150" y1="0" x2="150" y2="450"/><line x1="200" y1="0" x2="200" y2="450"/><line x1="250" y1="0" x2="250" y2="450"/><line x1="300" y1="0" x2="300" y2="450"/><line x1="350" y1="0" x2="350" y2="450"/><line x1="400" y1="0" x2="400" y2="450"/><line x1="450" y1="0" x2="450" y2="450"/><line x1="500" y1="0" x2="500" y2="450"/><line x1="550" y1="0" x2="550" y2="450"/><line x1="600" y1="0" x2="600" y2="450"/><line x1="0" y1="0" x2="600" y2="0"/><line x1="0" y1="50" x2="600" y2="50"/><line x1="0" y1="100" x2="600" y2="100"/><line x1="0" y1="150" x2="600" y2="150"/><line x1="0" y1="200" x2="600" y2="200"/><line x1="0" y1="250" x2="600" y2="250"/><line x1="0" y1="300" x2="600" y2="300"/><line x1="0" y1="350" x2="600" y2="350"/><line x1="0" y1="400" x2="600" y2="400"/><line x1="0" y1="450" x2="600" y2="450"/></g>
    <g stroke="#1F2724" stroke-opacity=".45" stroke-width="1" fill="none">
      <line x1="300" y1="0" x2="300" y2="450" stroke-dasharray="3 5"/><line x1="0" y1="225" x2="600" y2="225" stroke-dasharray="3 5"/>
      <rect x="200" y="150" width="200" height="150"/><rect x="250" y="187.5" width="100" height="75"/>
    </g>
  </svg>
  <span class="coords">3.1308° N · 101.6120° E</span>
  <div class="map-pin" aria-hidden="true"><span class="pin-head"><svg viewBox="0 0 650 500"><use href="#pd-symbol"/></svg></span><span class="pin-stem"></span><span class="pin-dot"></span></div>
  <div class="map-card"><p>The interactive Google Map loads here on the live site when tapped, so it never slows the page.</p>
    <a class="btn btn-ink btn-sm" href="https://www.google.com/maps/search/?api=1&amp;query=Padel%20District%2C%20227%20Jalan%20Kenanga%2C%20Petaling%20Jaya&amp;query_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="map_card">Open in Google Maps <span class="arr" aria-hidden="true">→</span></a></div>
</div>
      </div>
    </div>
  </section>

<!-- ===== SECTION 09 · FAQ ===== -->
<section class="section band-stone" aria-labelledby="faq-title">
    <div class="wrap grid faq-grid">
      <div class="q-head stack-3">
        <p class="eyebrow">FAQ</p>
        <h2 class="h-xl" id="faq-title">Good to know.</h2>
        <p class="muted">The questions people ask before their first game.</p>
        <a class="tlink" href="<?php echo esc_url( pd_url( 'faq' ) ); ?>">All questions <span class="arr" aria-hidden="true">→</span></a>
      </div>
      <div class="q-list">
        <div class="faq"><details name="faq-home"><summary>How do I book a court? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Book on Playtomic, on the web or in the app. Open Padel District, pick a time and a court, and confirm. <a href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="faq_answer">Book a Court with Playtomic →</a></p></div></details>
<details name="faq-home"><summary>What are your opening hours? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>We’re open every day from 7:00 AM to 12:00 AM (midnight).</p></div></details>
<details name="faq-home"><summary>Where is Padel District located? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>227, Jalan Kenanga, Kampung Sungai Kayu Ara, 47400 Petaling Jaya, Selangor. <a href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="faq_answer">Get directions →</a></p></div></details>
<details name="faq-home"><summary>Do I need to bring my own racket? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>No. Rackets and balls are available at the District. <span class="pending">To confirm: rental or borrowing terms and any fee</span></p></div></details>
<details name="faq-home"><summary>Is Padel District suitable for beginners? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Yes. All seven courts are open to every level, and you book them the same way as everyone else.</p></div></details>
<details name="faq-home"><summary>How many courts are available? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Seven indoor, panoramic doubles courts: Padel 01–06 and Centre Court.</p></div></details>
<details name="faq-home"><summary>Where can I find parking information? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Free parking is listed on our Playtomic page. <span class="pending">To confirm: where to park and how many bays</span></p></div></details>
<details name="faq-home"><summary>Can I cancel or change my booking? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Changes and cancellations are handled in Playtomic, under the booking terms shown when you book. Open your booking in the Playtomic app to see your options.</p></div></details>
<details name="faq-home"><summary>Are food and drinks available? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p>Food and drinks are coming soon. For now, there’s a water dispenser on site.</p></div></details>
<details name="faq-home"><summary>How do I contact the team? <span class="pm" aria-hidden="true"></span></summary><div class="a"><p><span class="pending">To confirm: phone, WhatsApp or email</span> You can also message us on Instagram at <a href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="faq_answer">@padeldistrict.my</a>.</p></div></details></div>
      </div>
    </div>
  </section>

<!-- ===== SECTION 10 · Final CTA ===== -->
<section class="band-sage final" aria-labelledby="final-title">
    <div class="court-lines" aria-hidden="true">
      <svg viewBox="0 0 200 100" fill="none" stroke="currentColor" stroke-width="1.25">
        <rect x="0" y="0" width="200" height="100" vector-effect="non-scaling-stroke"/>
        <line x1="100" y1="-6" x2="100" y2="106" stroke-width="2" vector-effect="non-scaling-stroke"/>
        <line x1="30.5" y1="0" x2="30.5" y2="100" vector-effect="non-scaling-stroke"/>
        <line x1="169.5" y1="0" x2="169.5" y2="100" vector-effect="non-scaling-stroke"/>
        <line x1="30.5" y1="50" x2="169.5" y2="50" vector-effect="non-scaling-stroke"/>
      </svg>
      <span class="lbl" style="left:0;top:calc(100% + 12px)">20 m × 10 m · one padel court</span>
    </div>
    <div class="wrap final-inner">
      <p class="eyebrow">Grounds for play.</p>
      <h2 id="final-title">See you on court.</h2>
      <p class="final-sub">Your next game starts here.</p>
      <a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="final_cta"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
    </div>
  </section>
</main>
