<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head">
    <div class="wrap stack-3">
      <p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>Courts</span></p>
      <h1 class="h-xl">Seven courts. One District.</h1>
      <p class="lede">Seven indoor, panoramic doubles courts in Kayu Ara, Petaling Jaya. Pick your court. Pick your time. Game on.</p>
      <div class="actions"><a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="courts_page_head"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a></div>
    </div>
  </header>
  <section class="section band-stone" aria-labelledby="cc-title">
    <div class="wrap grid courts-grid">
      <div class="c-copy stack-3">
        <h2 class="h-l" id="cc-title">The layout</h2>
        <p class="lede">Centre Court on the left, Padel 01 to 06 on the right.</p>
        <ul class="court-list">
          <li class="is-centre"><span class="n">CC</span><span><b>Centre Court</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">01</span><span><b>Padel 01</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">02</span><span><b>Padel 02</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">03</span><span><b>Padel 03</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">04</span><span><b>Padel 04</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">05</span><span><b>Padel 05</b>Indoor · panoramic glass · doubles</span></li>
          <li><span class="n">06</span><span><b>Padel 06</b>Indoor · panoramic glass · doubles</span></li>
        </ul>
        <p class="caption">On Playtomic the courts appear as Padel 1–6 and Centre Court. <span class="pending">To confirm: signage naming and the order of 01–06</span></p>
      </div>
      <div class="c-plan">
        <figure class="plan"><svg viewBox="-1 -5.5 58.5 79" role="img" aria-label="Court layout: Centre Court on the left; Padel 01 to 06 stacked on the right"><text x="10" y="29.05" text-anchor="middle" font-size="1.9" font-weight="600" letter-spacing=".22" fill="#1F2724">CENTRE COURT</text><text x="40" y="-2.4" text-anchor="middle" font-size="1.9" font-weight="600" letter-spacing=".22" fill="#1F2724">PADEL 01–06</text><g transform="translate(0 31.25)"><rect x="0" y="0" width="20" height="10" fill="#1F2724" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#F1F2EA" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#F1F2EA" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g></g><g transform="translate(30 0.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">01</text></g><g transform="translate(30 12.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">02</text></g><g transform="translate(30 25.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">03</text></g><g transform="translate(30 37.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">04</text></g><g transform="translate(30 50.0)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">05</text></g><g transform="translate(30 62.5)"><rect x="0" y="0" width="20" height="10" fill="none" stroke="#1F2724" stroke-width="1.5" vector-effect="non-scaling-stroke"/><line x1="10" y1="-0.6" x2="10" y2="10.6" stroke="#1F2724" stroke-width="2.25" vector-effect="non-scaling-stroke"/><g stroke="#1F2724" stroke-opacity=".5" stroke-width="1"><line x1="3.05" y1="0" x2="3.05" y2="10" vector-effect="non-scaling-stroke"/><line x1="16.95" y1="0" x2="16.95" y2="10" vector-effect="non-scaling-stroke"/><line x1="3.05" y1="5" x2="16.95" y2="5" vector-effect="non-scaling-stroke"/></g><text x="22.2" y="5" dominant-baseline="central" font-size="4.3" font-weight="600" letter-spacing="-.15" fill="#1F2724" style="font-family:var(--display)">06</text></g></svg><figcaption>Indicative plan of the District’s seven courts, each 20 × 10 m. Spacing not to scale.</figcaption></figure>
      </div>
    </div>
  </section>
  <section class="section" aria-label="On court">
    <div class="wrap">
      <div class="media ratio-169">
        <img src="<?php echo esc_url( pd_img( 'game-1600.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'game-800.webp' ) ); ?> 800w, <?php echo esc_url( pd_img( 'game-1600.webp' ) ); ?> 1600w" sizes="100vw" loading="lazy" width="1600" height="1073" alt="Four players in a doubles rally on an indoor padel court" style="object-position:50% 60%">
        <span class="asset-tag">AI visualisation · replace with venue photo</span>
      </div>
    </div>
  </section>
  <section class="section rule-top" aria-labelledby="onsite-title">
    <div class="wrap stack-4">
      <div class="stack-3"><p class="eyebrow">On site</p><h2 class="h-l" id="onsite-title">What’s here when you arrive.</h2></div>
      <ul class="amen">
        <li><span>Rackets &amp; balls</span><span class="pending">To confirm: terms</span></li>
        <li><span>Towels</span></li>
        <li><span>Air-conditioned restrooms</span></li>
        <li><span>Changing room</span></li>
        <li><span>Surau</span></li>
        <li><span>Water dispenser</span></li>
        <li><span>Free parking</span><span class="pending">To confirm: where</span></li>
        <li><span>Store</span><span class="pending">To confirm: what it stocks</span></li>
        <li><span>Disabled access</span><span class="pending">To confirm: details</span></li>
      </ul>
      <p class="caption">As published by Padel District in the brand brief and on its Playtomic listing.</p>
    </div>
  </section>
  <section class="section" aria-label="Book a court">
    <div class="wrap"><div class="cta-band"><h2>Pick your court. Pick your time.</h2><a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="courts_page_band"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a></div></div>
  </section>
</main>
