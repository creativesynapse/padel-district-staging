<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="page-head band-ink on-dark" style="border-bottom:0">
    <div class="wrap stack-3">
      <p class="crumb" style="color:var(--off-soft)"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>Food &amp; Drinks</span></p>
      <span class="soon">Coming soon</span>
      <h1 class="h-xl">More to come at the District.</h1>
      <p class="lede">We’re making room for more than just the game. Food, drinks and new reasons to stay are on the way.</p>
      <div class="actions"><a class="btn btn-line" href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="fnb_page">Follow @padeldistrict.my <span class="arr" aria-hidden="true">→</span></a></div>
    </div>
  </header>
  <section class="section band-ink on-dark" style="padding-top:0" aria-labelledby="later-title">
    <div class="wrap stack-4">
      <div class="rule-top" style="border-color:var(--rule-dark);padding-top:var(--sp-4)">
        <span class="tag" style="background:var(--off);color:var(--ink)">Mockup note</span>
        <h2 class="h-m" id="later-title" style="margin-top:var(--sp-2)">At launch, this page fills in from WordPress</h2>
      </div>
      <ul class="later">
        <li><b>Restaurants &amp; bars</b><span>Each operator’s own name and logo, shown as “Padel District × Partner”.</span></li>
        <li><b>Menus &amp; opening hours</b><span>Per venue, edited by the team. Nothing shown until confirmed.</span></li>
        <li><b>Reservations &amp; links</b><span>Each partner’s booking or menu link, and a dining gallery.</span></li>
      </ul>
    </div>
  </section>
  <section class="section" aria-label="Until then">
    <div class="wrap"><div class="cta-band"><div class="stack-2"><h2>Until then, the courts are open.</h2><p class="muted">There’s a water dispenser on site for between games.</p></div><a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="fnb_page_band"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a></div></div>
  </section>
</main>
