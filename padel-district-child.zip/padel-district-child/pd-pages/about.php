<?php defined( 'ABSPATH' ) || exit; ?>
<main id="main" tabindex="-1">
  <header class="ab-open">
    <div class="wrap">
      <p class="crumb"><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a><span aria-hidden="true">/</span><span>About</span></p>
      <h1 class="ab-title">A good game deserves a good place to happen.</h1>
      <dl class="titleblock">
        <div><dt>Name</dt><dd>Padel District</dd></div>
        <div><dt>Location</dt><dd>Kayu Ara, Petaling Jaya</dd></div>
        <div><dt>Courts</dt><dd class="num">07, indoor</dd></div>
        <div><dt>Hours</dt><dd class="num">8AM–12AM, daily</dd></div>
      </dl>
    </div>
  </header>

  <figure class="ab-figure">
    <div class="media ab-wide">
      <picture><source media="(max-width:699px)" srcset="<?php echo esc_url( pd_img( 'pd-about-mobile-700.webp' ) ); ?> 700w, <?php echo esc_url( pd_img( 'pd-about-mobile-1250.webp' ) ); ?> 1250w" sizes="100vw"><img src="<?php echo esc_url( pd_img( 'pd-about-wide-1449.webp' ) ); ?>" srcset="<?php echo esc_url( pd_img( 'pd-about-wide-900.webp' ) ); ?> 900w, <?php echo esc_url( pd_img( 'pd-about-wide-1449.webp' ) ); ?> 1449w" sizes="100vw" width="1449" height="621" loading="lazy" style="object-position:50% 30%" alt="Two players high-fiving between points on a blue court"></picture>
    </div>
    <figcaption class="wrap"><span class="fig">Fig. 01</span><span>A high five between points at Padel District, Kayu Ara.</span></figcaption>
  </figure>

  <section class="section ab-story" aria-labelledby="story-title">
    <div class="wrap grid">
      <h2 class="ab-side" id="story-title">Grounds<br>for play.</h2>
      <div class="ab-body">
        <p class="eyebrow">Padel District – Grounds for play</p>
        <p class="ab-lead">Padel is what brings us together. Everything else is what makes us stay.</p>
        <p>Located in Kayu Ara, Petaling Jaya, Padel District is a seven-court padel destination built around a simple idea: great experiences happen both on and off the court.</p>
        <p>We want to create a place where people come not just to play, but to have fun, enjoy good vibes and connect with others. Whether it’s a family day out, a friendly game with friends, meeting new people or simply enjoying some time away from the everyday routine, there’s always a reason to be here.</p>
        <p>Beyond the game, it’s about the familiar faces, spontaneous conversations, post-game catch-ups and friendships that grow along the way. It’s about building a community where everyone feels welcome, where different generations and groups can come together, and where the fun doesn’t have to stop when the game ends.</p>
        <p>Padel District is also a space to bring people together for special occasions and events, from social gatherings and celebrations to corporate get-togethers, team-building activities and company events.</p>
        <p>With our courts, food and beverage offerings, bar and pro shop, we offer an environment where people can play, socialise and enjoy the experience together.</p>
        <p>Because while padel may be the reason you first walk through our doors, we hope it’s the people, the atmosphere, the good vibes and the experiences that keep bringing you back.</p>
      </div>
    </div>
  </section>

  <section class="section band-ink on-dark ab-court" aria-labelledby="court-title">
    <div class="wrap grid">
      <div class="ab-court-copy stack-3">
        <h2 class="h-l" id="court-title">What we built seven of.</h2>
        <p>Every court at the District is indoor, glass-walled and made for doubles: 20 by 10 metres, a net across the middle and a service line 6.95 metres either side of it.</p>
        <a class="tlink" href="<?php echo esc_url( pd_url( 'courts' ) ); ?>">See the court layout <span class="arr" aria-hidden="true">→</span></a>
      </div>
      <div class="ab-court-art">
        <svg viewBox="0 0 270 160" role="img" aria-label="Padel court drawing: 20 metres long, 10 metres wide, net in the middle, service lines 6.95 metres from the net" style="font-family:var(--text)">
<g fill="none" stroke="#F1F2EA" stroke-width="1.5" vector-effect="non-scaling-stroke">
<rect x="30" y="30" width="200" height="100" vector-effect="non-scaling-stroke"/>
<g stroke-opacity=".55" stroke-width="1"><line x1="60.5" y1="30" x2="60.5" y2="130" vector-effect="non-scaling-stroke"/><line x1="199.5" y1="30" x2="199.5" y2="130" vector-effect="non-scaling-stroke"/><line x1="60.5" y1="80" x2="199.5" y2="80" vector-effect="non-scaling-stroke"/></g>
</g>
<line x1="130" y1="23" x2="130" y2="137" stroke="#F2C14E" stroke-width="3" vector-effect="non-scaling-stroke"/>
<g stroke="#F1F2EA" stroke-opacity=".7" stroke-width="1" vector-effect="non-scaling-stroke">
<line x1="30" y1="14" x2="230" y2="14" vector-effect="non-scaling-stroke"/><line x1="30" y1="10" x2="30" y2="18" vector-effect="non-scaling-stroke"/><line x1="230" y1="10" x2="230" y2="18" vector-effect="non-scaling-stroke"/>
<line x1="246" y1="30" x2="246" y2="130" vector-effect="non-scaling-stroke"/><line x1="242" y1="30" x2="250" y2="30" vector-effect="non-scaling-stroke"/><line x1="242" y1="130" x2="250" y2="130" vector-effect="non-scaling-stroke"/>
<line x1="130" y1="146" x2="199.5" y2="146" vector-effect="non-scaling-stroke"/><line x1="130" y1="142" x2="130" y2="150" vector-effect="non-scaling-stroke"/><line x1="199.5" y1="142" x2="199.5" y2="150" vector-effect="non-scaling-stroke"/>
</g>
<g fill="#F1F2EA" font-size="7.5" font-weight="600">
<text x="130" y="9" text-anchor="middle">20 m</text>
<text x="252" y="83" >10 m</text>
<text x="164.75" y="158" text-anchor="middle">6.95 m</text>
</g>
<text x="134" y="45" fill="#F2C14E" font-size="6.5" font-weight="600" letter-spacing=".8">NET</text>
<text x="64" y="45" fill="#F1F2EA" fill-opacity=".75" font-size="5.5" font-weight="600" letter-spacing=".6">SERVICE LINE</text>
</svg>
      </div>
    </div>
  </section>

  <section class="section ab-values" aria-labelledby="values-title">
    <div class="wrap">
      <h2 class="h-l" id="values-title">What we stand for</h2>
      <dl class="vrows">
        <div><dt>Open</dt><dd>Everyone is welcome, from first rally to league night.</dd></div>
        <div><dt>Considered</dt><dd>The details are done properly, so you don’t have to think about them.</dd></div>
        <div><dt>Social</dt><dd>The game is better together, and so is what comes after.</dd></div>
        <div><dt>Active</dt><dd>Keep moving, keep improving, keep it light.</dd></div>
      </dl>
    </div>
  </section>

  <section class="section band-stone ab-next" aria-labelledby="now-title">
    <div class="wrap">
      <h2 class="h-l" id="now-title">Now and next</h2>
      <ol class="timeline">
        <li class="is-now"><span class="when">Now</span><b>Courts</b><span>Seven courts, open daily 8:00 AM – 12:00 AM.</span><a class="tlink" href="<?php echo esc_url( pd_url( 'courts' ) ); ?>">The courts <span class="arr" aria-hidden="true">→</span></a></li>
        <li><span class="when">Coming soon</span><b>Food &amp; drinks</b><span>New reasons to stay a little longer.</span><a class="tlink" href="<?php echo esc_url( pd_url( 'food-drinks' ) ); ?>">Food &amp; Drinks <span class="arr" aria-hidden="true">→</span></a></li>
        <li><span class="when">Later</span><b>Events &amp; community</b><span>News and events here once there’s something to share.</span></li>
      </ol>
    </div>
  </section>

  <section class="section ab-end" aria-label="Book a court">
    <div class="wrap"><div class="ab-cta"><h2>See you on court.</h2><a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="about_page_band"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a></div></div>
  </section>
</main>
