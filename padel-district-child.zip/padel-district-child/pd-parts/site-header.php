<?php defined( 'ABSPATH' ) || exit; ?>
<a class="skip" href="#main">Skip to content</a>

<header class="site-header" id="site-header">
  <div class="wrap header-inner">
    <a class="brand" href="<?php echo esc_url( pd_url( 'home' ) ); ?>" aria-label="Padel District home">
      <svg class="logo-h" viewBox="0 0 1526.56 168" role="img" aria-label="Padel District"><use href="#pd-horizontal"/></svg>
    </a>
    <nav class="primary-nav" aria-label="Primary">
      <ul>
        <li><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>" data-nav="home"<?php pd_current( 'home' ); ?>>Home</a></li>
        <li><a href="<?php echo esc_url( pd_url( 'courts' ) ); ?>" data-nav="courts"<?php pd_current( 'courts' ); ?>>Courts</a></li>
        <li><a href="<?php echo esc_url( pd_url( 'about' ) ); ?>" data-nav="about"<?php pd_current( 'about' ); ?>>About</a></li>
        <li><a href="<?php echo esc_url( pd_url( 'food-drinks' ) ); ?>" data-nav="food-drinks"<?php pd_current( 'food-drinks' ); ?>>Food &amp; Drinks</a></li>
        <li><a href="<?php echo esc_url( pd_url( 'visit' ) ); ?>" data-nav="visit"<?php pd_current( 'visit' ); ?>>Visit Us</a></li>
        <li><a href="<?php echo esc_url( pd_url( 'faq' ) ); ?>" data-nav="faq"<?php pd_current( 'faq' ); ?>>FAQ</a></li>
      </ul>
    </nav>
    <a class="btn btn-sun btn-book btn-sm header-cta" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="header"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
    <button class="menu-toggle" id="menu-toggle" type="button" aria-expanded="false" aria-controls="mobile-menu">Menu <span class="bars" aria-hidden="true"></span></button>
  </div>
</header>

<div class="mobile-menu" id="mobile-menu" hidden>
  <div class="wrap">
    <a class="btn btn-sun btn-book btn-block" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="mobile_menu"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
    <nav aria-label="Mobile">
      <a href="<?php echo esc_url( pd_url( 'home' ) ); ?>" data-nav="home"<?php pd_current( 'home' ); ?>>Home</a>
      <a href="<?php echo esc_url( pd_url( 'courts' ) ); ?>" data-nav="courts"<?php pd_current( 'courts' ); ?>>Courts</a>
      <a href="<?php echo esc_url( pd_url( 'visit' ) ); ?>" data-nav="visit"<?php pd_current( 'visit' ); ?>>Visit Us</a>
      <a href="<?php echo esc_url( pd_url( 'about' ) ); ?>" data-nav="about"<?php pd_current( 'about' ); ?>>About</a>
      <a href="<?php echo esc_url( pd_url( 'food-drinks' ) ); ?>" data-nav="food-drinks"<?php pd_current( 'food-drinks' ); ?>>Food &amp; Drinks</a>
      <a href="<?php echo esc_url( pd_url( 'faq' ) ); ?>" data-nav="faq"<?php pd_current( 'faq' ); ?>>FAQ</a>
    </nav>
    <div class="mm-meta">
      <span><strong>Open daily</strong> 8:00 AM – 12:00 AM</span>
      <span>227, Jalan Kenanga, Kampung Sungai Kayu Ara, 47400 Petaling Jaya</span>
      <span><a class="tlink" href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="mobile_menu">Get directions <span class="arr" aria-hidden="true">→</span></a></span>
    </div>
  </div>
</div>

