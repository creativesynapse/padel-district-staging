<?php defined( 'ABSPATH' ) || exit; ?>


<footer class="site-footer on-dark" id="site-footer">
  <div class="wrap">
    <div class="f-top">
      <div class="f-brand stack-3">
        <a class="brand" href="<?php echo esc_url( pd_url( 'home' ) ); ?>" aria-label="Padel District home"><svg class="logo-h" viewBox="0 0 1526.56 168" role="img" aria-label="Padel District"><use href="#pd-horizontal"/></svg></a>
        <p class="f-line">GROUNDS FOR PLAY.</p>
        <div><a class="btn btn-sun btn-book" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="footer"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a></div>
      </div>
      <div class="f-cols">
        <div class="f-col">
          <h2>Explore</h2>
          <ul>
            <li><a href="<?php echo esc_url( pd_url( 'home' ) ); ?>">Home</a></li>
            <li><a href="<?php echo esc_url( pd_url( 'courts' ) ); ?>">Courts</a></li>
            <li><a href="<?php echo esc_url( pd_url( 'about' ) ); ?>">About</a></li>
            <li><a href="<?php echo esc_url( pd_url( 'food-drinks' ) ); ?>">Food &amp; Drinks</a></li>
            <li><a href="<?php echo esc_url( pd_url( 'visit' ) ); ?>">Visit Us</a></li>
            <li><a href="<?php echo esc_url( pd_url( 'faq' ) ); ?>">FAQ</a></li>
          </ul>
        </div>
        <div class="f-col">
          <h2>Visit</h2>
          <address>227, Jalan Kenanga,<br>Kampung Sungai Kayu Ara,<br>47400 Petaling Jaya, Selangor</address>
          <p style="margin-top:.75rem" class="num">Daily, 8:00 AM – 12:00 AM</p>
          <ul style="margin-top:.75rem">
            <li><a href="https://www.google.com/maps/dir/?api=1&amp;destination=Padel%20District&amp;destination_place_id=ChIJdQAdQVZPzDERYbTECX2S6Vg" target="_blank" rel="noopener" data-track="directions_click" data-provider="google_maps" data-cta="footer">Google Maps ↗</a></li>
            <li><a href="https://waze.com/ul/hw283b1zxq" target="_blank" rel="noopener" data-track="directions_click" data-provider="waze" data-cta="footer">Waze ↗</a></li>
          </ul>
        </div>
        <div class="f-col">
          <h2>Connect</h2>
          <ul>
            <li><a href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="footer_list">Book on Playtomic ↗</a></li>
            <li><a href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="footer">Instagram ↗</a></li>
          </ul>
          <p style="margin-top:.9rem"><span class="pending">Contact details to confirm</span></p>
        </div>
      </div>
    </div>
    <div class="f-bottom">
      <span>© <?php echo esc_html( wp_date( 'Y' ) ); ?> Padel District. All rights reserved.</span>
      <ul><li><a href="<?php echo esc_url( pd_url( 'privacy' ) ); ?>">Privacy Policy</a></li><li><a href="<?php echo esc_url( pd_url( 'terms' ) ); ?>">Website Terms</a></li></ul>
    </div>
  </div>
</footer>

<div class="book-bar" id="book-bar">
  <a class="btn btn-sun btn-book btn-block" href="https://playtomic.com/clubs/padel-district?utm_source=app_android&amp;utm_campaign=share" target="_blank" rel="noopener" data-track="book_court_click" data-cta="mobile_sticky_bar"><span>Book a Court with</span><svg class="pt-logo" viewBox="0 0 1028 171" role="img" aria-label="Playtomic"><use href="#pt-logo"/></svg><span class="arr" aria-hidden="true">→</span></a>
</div>

<div class="wa" id="wa">
  <div class="wa-pop" id="wa-pop" role="dialog" aria-labelledby="wa-pop-title" hidden>
    <div class="wa-pop-head"><b id="wa-pop-title">Chat on WhatsApp</b><button class="wa-x" type="button" id="wa-close" aria-label="Close">✕</button></div>
    <p>Our WhatsApp number is being set up. For now, message us on Instagram and we’ll get back to you.</p>
    <a class="tlink" href="https://www.instagram.com/padeldistrict.my/" target="_blank" rel="noopener" data-track="instagram_click" data-cta="whatsapp_fallback">Message @padeldistrict.my <span class="arr" aria-hidden="true">↗</span></a>
    <span class="pending">To confirm: WhatsApp number</span>
  </div>
  <a class="wa-btn" id="wa-btn" href="#" data-track="whatsapp_click" data-cta="floating_button" aria-label="Chat with Padel District on WhatsApp" aria-controls="wa-pop" aria-expanded="false"><svg viewBox="0 0 346 346" aria-hidden="true"><use href="#wa-glyph"/></svg></a>
</div>

<dialog class="lightbox" id="lightbox" aria-labelledby="lb-title">
  <div class="lb-inner">
    <div class="lb-bar"><span id="lb-title">Gallery</span><button class="lb-btn" type="button" id="lb-close">Close ✕</button></div>
    <div class="lb-img"><img id="lb-img" src="" alt=""></div>
    <div class="lb-foot">
      <button class="lb-btn" type="button" id="lb-prev" aria-label="Previous image">← Prev</button>
      <span><span id="lb-count" class="num"></span> · <span style="color:var(--off-soft)">AI visualisation · replace with venue photo</span></span>
      <button class="lb-btn" type="button" id="lb-next" aria-label="Next image">Next →</button>
    </div>
  </div>
</dialog>
